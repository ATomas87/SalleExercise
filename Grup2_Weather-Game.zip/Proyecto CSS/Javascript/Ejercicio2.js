let listaNavItem = document.getElementsByClassName("");


document.addEventListener("DOMContentLoaded", function (event) {
    Array.from(listaNavItem).forEach((element) => {
        // Do stuff here
        element.addEventListener("click", function(){
            
        })
    });
})